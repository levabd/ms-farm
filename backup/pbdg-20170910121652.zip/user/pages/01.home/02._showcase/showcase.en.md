---
title: Showcase
metadata:
    icon1: icon_briefcase
    title1: We create careers and open new posibbilities for our clients
    text1: We present a unique opportunity for investors to access IFC’s superior track record in emerging markets, its unparalleled network of in-country presence and expertise.
    icon2: icon_piechart
    title2: We create careers and open new posibbilities for our clients
    text2: We present a unique opportunity for investors to access IFC’s superior track record in emerging markets, its unparalleled network of in-country presence and expertise.
    icon3: icon_comment_alt
    title3: We create careers and open new posibbilities for our clients
    text3: We present a unique opportunity for investors to access IFC’s superior track record in emerging markets, its unparalleled network of in-country presence and expertise.
    icon4: icon_document_alt
    title4: We create careers and open new posibbilities for our clients
    text4: We present a unique opportunity for investors to access IFC’s superior track record in emerging markets, its unparalleled network of in-country presence and expertise.
---

