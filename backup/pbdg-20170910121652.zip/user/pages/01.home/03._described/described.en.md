---
title: 'Our company described in numbers'
metadata:
    percent1_text: 'Career Opportunities'
    percent1_percent: '65'
    percent2_text: ' Career Opportunities2'
    percent2_percent: '20'
    mark1_text: 'Total Assets Raised'
    mark1_index: '19600'
    mark2_text: 'Number Of Funds'
    mark2_index: '27'
    mark3_text: Investments
    mark3_index: '20412'
    mark4_text: 'Portfolio Companies'
    mark4_index: '250'
    mark5_text: 'Total Assets Raised'
    mark5_index: '900'
    mark6_text: 'Total Assets Raised'
    mark6_index: '1057'
---

