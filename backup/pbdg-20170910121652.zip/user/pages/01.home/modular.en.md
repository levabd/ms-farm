---
title: Home
content:
    items: '@self.modular'
    order:
        by: default
        dir: asc
        custom:
            - _header
            - _showcase
            - _described
            - _features
            - _team
menu: Home
onpage_menu: true
---

